﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JorgePaguay.Repository
{
    public class RespuestaModelo
    {
        public RespuestaModelo()
        {
            root = new List<Object>();
        }
        public int codigoError { get; set; }
        public string mensajeError { get; set; }
        public List<Object> root { get; set; }
    }
}
