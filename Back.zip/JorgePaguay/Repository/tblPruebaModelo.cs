﻿using JorgePaguay.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace JorgePaguay.Repository
{
    public class tblPruebaModelo
    {

        public static RespuestaModelo consultaTablaTest(tblPruebaTest tblpruebaTest)
        {
            DataSet dt = new DataSet();
            RespuestaModelo respuestaModelo = new RespuestaModelo();
            SqlCommand cmd = new SqlCommand();
            try
            {
                SqlConnection con = new SqlConnection(VariablesGlobal.conexion);
                cmd = new SqlCommand("sp_consulta_registro", con);
                cmd.Parameters.AddWithValue("@id", tblpruebaTest.id);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 0;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                if (dt == null || dt.Tables.Count == 0 || dt.Tables[0].Rows.Count == 0 )
                {
                    respuestaModelo.codigoError = 999;
                    respuestaModelo.mensajeError = "No existe informacion.";
                }
                else
                {
                    respuestaModelo.codigoError = (int)dt.Tables[0].Rows[0]["codigoError"];
                    respuestaModelo.mensajeError = dt.Tables[0].Rows[0]["mensajeError"].ToString();
                    if (dt.Tables.Count > 1)
                    {
                        respuestaModelo.root.Add(dt.Tables[1]);
                    }
                    else
                    {
                        respuestaModelo.root = null;
                    }
                }
            }
            catch (Exception err)
            {
                respuestaModelo.codigoError = 999;
                respuestaModelo.mensajeError = "Error consulte con el administrador";
            }
            finally
            {
                cmd.Dispose();
            }
            return respuestaModelo;
        }


        public static RespuestaModelo mantenimientoTablaTest(tblPruebaTest tblpruebaTest)
        {
            DataSet dt = new DataSet();
            RespuestaModelo respuestaModelo = new RespuestaModelo();
            SqlCommand cmd = new SqlCommand();
            try
            {
                SqlConnection con = new SqlConnection(VariablesGlobal.conexion);
                cmd = new SqlCommand("sp_mantenimiento_registro", con);
                cmd.Parameters.AddWithValue("@Opcion", tblpruebaTest.opcion);
                cmd.Parameters.AddWithValue("@Id", tblpruebaTest.id);
                cmd.Parameters.AddWithValue("@Titulo", tblpruebaTest.titulo);
                cmd.Parameters.AddWithValue("@Descripcion", tblpruebaTest.descripcion); 
                cmd.Parameters.AddWithValue("@FechaCreacion", tblpruebaTest.fechaCreacion);
                cmd.Parameters.AddWithValue("@FechaVencimiento", tblpruebaTest.fechaVencimiento);
                cmd.Parameters.AddWithValue("@Completada", tblpruebaTest.completada);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 0;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                if (dt == null || dt.Tables.Count == 0 || dt.Tables[0].Rows.Count == 0 || !dt.Tables[0].Columns.Contains("codigoError"))
                {
                    respuestaModelo.codigoError = 999;
                    respuestaModelo.mensajeError = "Error consulte con el administrador";
                }
                else
                {
                    respuestaModelo.codigoError = (int)dt.Tables[0].Rows[0]["codigoError"];
                    respuestaModelo.mensajeError = dt.Tables[0].Rows[0]["mensajeError"].ToString();
                    if (dt.Tables.Count > 1)
                    {
                        respuestaModelo.root.Add(dt.Tables[1]);
                    }
                    else
                    {
                        respuestaModelo.root = null;
                    }
                }
            }
            catch (Exception err)
            {
                respuestaModelo.codigoError = 999;
                respuestaModelo.mensajeError = "Error consulte con el administrador";
            }
            finally
            {
                cmd.Dispose();
            }
            return respuestaModelo;

        }
    }
}
