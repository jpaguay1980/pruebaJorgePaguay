﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JorgePaguay.Models
{
    public class tblPruebaTest
    {
        public string opcion { get; set; }
        public int id { get; set; }
        public string titulo { get; set; }
        public string descripcion { get; set; }
        public DateTime fechaCreacion { get; set; }
        public DateTime fechaVencimiento { get; set; }
        public string completada { get; set; }
    }
}
