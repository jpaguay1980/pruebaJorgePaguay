﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JorgePaguay.Models
{
    public class VariablesGlobal
    {
        public static string conexion { get; set; }
    }
}
