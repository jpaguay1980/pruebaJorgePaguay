﻿using JorgePaguay.Models;
using JorgePaguay.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JorgePaguay.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TblPruebaTestController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost("consultaTablaTest")]
        public IActionResult consultaVehiculoTest(tblPruebaTest tblpruebatest)
        {
            try
            {
                RespuestaModelo respuestaModelo = tblPruebaModelo.consultaTablaTest(tblpruebatest);
                return Ok(respuestaModelo);
            }
            catch (Exception ex)
            {
                string m = ex.Message;
                return Ok(m);
            }
        }


        [HttpPost("mantenimientoTablaTest")]
        public IActionResult mantenimientoTablaTest(tblPruebaTest tblpruebatest)
        {
            try
            {
                RespuestaModelo respuestaModelo = tblPruebaModelo.mantenimientoTablaTest(tblpruebatest);
                return Ok(respuestaModelo);
            }
            catch (Exception ex)
            {
                string m = ex.Message;
                return Ok(m);
            }
        }
    }
}
